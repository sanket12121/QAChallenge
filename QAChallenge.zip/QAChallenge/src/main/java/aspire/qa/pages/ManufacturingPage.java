package aspire.qa.pages;

import java.awt.List;

import javax.swing.Action;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import aspire.qa.base.TestBase;

public class ManufacturingPage extends TestBase{
	
	
	
	@FindBy(xpath="//button[contains(text(),'Create')]")
	WebElement Manufacturing_create;
	

	@FindBy(xpath="//button[@name='action_confirm']")
	WebElement action_Confirm;
	
	@FindBy(xpath="//button[@name='button_mark_done'][3]")
	WebElement action_Done;
	
	@FindBy(xpath="//button[contains(text(),'Save')]")
	WebElement save;
	
	@FindBy(xpath="//input[@id='o_field_input_193']")
	WebElement product;
	
	@FindBy(xpath="//input[@name='qty_producing']")
	WebElement quantity;
	
	@FindBy(xpath="//tr[@class='o_data_row o_selected_row']/td[6]/input")
	WebElement quantity_consumed;
	
	@FindBy(xpath="//*[@class='o_list_number_th' and contains(text(),'Consumed')]")
	WebElement consumed;
	
	
	
	
	public ManufacturingPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void create_new_MO() throws InterruptedException
	{
		Manufacturing_create.click();
		Thread.sleep(3000);
		//List<Webelement> product = driver.findElements(By.xpath("//input[@id='o_field_input_193']"));
		//product.get(1).click();
		//product.get(1).sendKeys(prop.getProperty("productname"));
		product.sendKeys(prop.getProperty("productname"));
		
		Thread.sleep(4000);
		action_Confirm.click();
		
		Thread.sleep(5000);
		quantity.clear();
		quantity.sendKeys(prop.getProperty("countedquantity"));
		
		java.util.List<WebElement> addline=driver.findElements(By.xpath("//*[@class='o_field_x2many_list_row_add']/child::a"));
		Thread.sleep(5000);
		addline.get(0).click();
		System.out.println("Add line clicked successfully");
		Thread.sleep(5000);
		java.util.List<WebElement> proddrop=driver.findElements(By.xpath("//*[@class='o_input_dropdown']/child::input[1]"));
		proddrop.get(2).click();
		proddrop.get(2).sendKeys(prop.getProperty("productname"));
		Thread.sleep(2000);
		
		consumed.click();
		System.out.println("Consumed clicked successfully");
		//Actions act = new Actions(driver);
		//act.doubleClick(quantity_consumed).perform();
		//System.out.println("Double clicked successfully");
		//quantity_consumed.clear();
		//System.out.println("cleared  successfully");
		Thread.sleep(2000);
		quantity_consumed.click();
		quantity_consumed.sendKeys(prop.getProperty("countedquantity"));
		
		System.out.println("Consumed entered successfully");
		
		action_Done.click();
		Thread.sleep(7000);
		save.click();
		System.out.println("Saved successfully");
		
		
	}
	
	public void verify_manufacturing_order() throws InterruptedException
	{
		
		
	String producttext= driver.findElement(By.xpath("//a[@id='o_field_input_193']")).getText();
	System.out.println(producttext);
	if(producttext.equals(prop.getProperty("productname")))
	{
		System.out.println("Product name validated");
	}else
	{
		System.out.println("Product name is not proper");
	}
	
	
	
	}

}
