package aspire.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import aspire.qa.base.TestBase;

public class InventoryPage extends TestBase{
	
	@FindBy(xpath="//*[@class='dropdown-toggle  ' and @title='Products']")
	WebElement productdropdown;
	
	@FindBy(xpath="//a[@class='dropdown-item']")
	WebElement productselect;
	
	
	@FindBy(xpath="//button[contains(text(),'Create')]")
	WebElement create;
	
	@FindBy(xpath="//input[@name='name']")
	WebElement productname;
	
	@FindBy(xpath="//button[@name='action_update_quantity_on_hand']")
	WebElement updatequantityclick;
	
	@FindBy(xpath="//tr[@class='o_data_row']/td[6]")
	WebElement countedquantity;
	
	@FindBy(xpath="//button[contains(text(),'Create')]")
	WebElement createquantityclick;
	
	@FindBy(xpath="//button[contains(text(),'Save')]")
	WebElement saveclick;
	
	@FindBy(xpath="//*[@class='o_main_navbar']/a[1]")
	WebElement homemenu;
	
	@FindBy(xpath="//td[@class='o_data_cell o_field_cell o_list_number o_counted_quantity_widget_cell']")
	WebElement Countqantitycell;
	
	
	
	public InventoryPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void Createproduct() throws InterruptedException
	{
		productdropdown.click();
		productselect.click();
		create.click();
		productname.sendKeys(prop.getProperty("productname"));
		updatequantityclick.click();
		Thread.sleep(4000);
		createquantityclick.click();
		Thread.sleep(3000);
		Countqantitycell.click();
		Countqantitycell.sendKeys(prop.getProperty("countedquantity"));
		saveclick.click();
		homemenu.click();
		
		
		
	}
}
