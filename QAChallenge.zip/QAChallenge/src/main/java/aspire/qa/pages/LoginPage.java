package aspire.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import aspire.qa.base.TestBase;

public class LoginPage extends TestBase {

	
	@FindBy(xpath="//input[@id='login']")
	WebElement emailfield;
	
	
	@FindBy(xpath="//input[@id='password']")
	WebElement pwdfield;
	
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement loginbtn;
	
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public void login() throws InterruptedException
	{
		//enter email id
		emailfield.sendKeys(prop.getProperty("username"));
		//enter password
		pwdfield.sendKeys(prop.getProperty("Password"));
		//click on login
		loginbtn.click();
		//verify login page displayed
		String current_url =driver.getCurrentUrl();
		if(!current_url.equals(prop.getProperty("url")))
		{
		Reporter.log("Login Successfull");
		System.out.println("Logged in");
		}
		
		
	}
}
