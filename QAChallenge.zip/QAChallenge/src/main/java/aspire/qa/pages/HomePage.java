package aspire.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import aspire.qa.base.TestBase;

public class HomePage extends TestBase{
	
	//div[@class='o_caption']
	@FindBy(xpath="//div[@class='o_caption' and contains(text(),'Inventory')]")
	WebElement inventory;
	
	@FindBy(xpath="//a[@id='result_app_2']")
	WebElement Manufacturing;
	
	@FindBy(xpath = "//img[@alt='User']")
	WebElement UserIcon;
	
	@FindBy(xpath = "//a[@class='dropdown-item focus']")
	WebElement Logout;
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}

	public void navigatetoinventory() throws InterruptedException
	{
		//click on invcentory
		inventory.click();
		Thread.sleep(2000);
		String title = driver.getTitle();
		System.out.println("Title is "+ title);
		
		if(title.contains("Inventory"))
		{
			System.out.println("Inventory page Displayed");
		}
		
	}
	
	public void navigatetomanufacturing() throws InterruptedException
	{
		//click on invcentory
		Manufacturing.click();
		Thread.sleep(2000);
		String title = driver.getTitle();
		System.out.println("Title is "+ title);
		
		if(title.contains("Manufacturing"))
		{
			System.out.println("Manufacturing page Displayed");
		}
		
	}
	
	public void Logout() throws InterruptedException
	{
		//click on logout
		        UserIcon.click();
                Thread.sleep(2000);
				Logout.click();
	}
}