package aspire.qa.util;

public class TestUtil {

	
	public static long IMPLICITLY_WAIT = 50;
	public static long PAGE_LOAD_TIMEOUT = 20;
}
