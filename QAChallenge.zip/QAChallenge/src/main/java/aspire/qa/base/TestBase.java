package aspire.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;



import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	public static WebDriver driver;

	public static Properties prop;
	
public TestBase()
{
	prop = new Properties();

	try {
		FileInputStream ip = new FileInputStream("C:\\Users\\Sanket Kale\\eclipse-workspace\\QAChallenge\\src\\main\\java\\aspire\\qa\\properties\\config.properties");
		prop.load(ip);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	
	public static void initializaton()
	{
		String browsername = prop.getProperty("browser");
		WebDriverManager.chromedriver().setup();
	if(browsername.equals("chrome")) {
		WebDriverManager.chromedriver().setup();
		   driver=new ChromeDriver();
		
	}else if(browsername.equals("FF")) {
		
		WebDriverManager.firefoxdriver().setup();
		 driver=new FirefoxDriver();
	
	  
	}
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().pageLoadTimeout(aspire.qa.util.TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(aspire.qa.util.TestUtil.IMPLICITLY_WAIT, TimeUnit.SECONDS);
	
	driver.navigate().to((prop.getProperty("url")));
}
}
