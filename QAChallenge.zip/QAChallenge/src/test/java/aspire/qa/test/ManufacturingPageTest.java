package aspire.qa.test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import aspire.qa.base.TestBase;
import aspire.qa.pages.HomePage;
import aspire.qa.pages.InventoryPage;
import aspire.qa.pages.LoginPage;
import aspire.qa.pages.ManufacturingPage;

public class ManufacturingPageTest extends TestBase{
	
	public LoginPage loginpage;
	public HomePage homepage;
	public InventoryPage inventorypage;
	public ManufacturingPage manufacturingpage;
	public HomePage Logout;
	
	public ManufacturingPageTest()
	{
		super();
	}
	
	@BeforeMethod
	public void setup() throws InterruptedException
	{
		initializaton();
		loginpage = new LoginPage();
		loginpage.login();
		homepage = new HomePage();
		homepage.navigatetoinventory();
		inventorypage = new InventoryPage();
		inventorypage.Createproduct();
		homepage.navigatetomanufacturing();
		manufacturingpage = new ManufacturingPage();
	}
	
	@Test
	public void create_new_MO_Test() throws InterruptedException
	{
		manufacturingpage.create_new_MO();
		manufacturingpage.verify_manufacturing_order();
	}
	@AfterMethod
	public void quit() throws InterruptedException
	{
	    driver.close();
	}

}