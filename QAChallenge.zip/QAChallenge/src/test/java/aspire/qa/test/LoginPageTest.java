package aspire.qa.test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import aspire.qa.base.TestBase;
import aspire.qa.pages.LoginPage;

public class LoginPageTest extends TestBase {

	public LoginPage loginpage;
public LoginPageTest()
{
	super();
}

@BeforeMethod
public void setup()
{
	initializaton();
	loginpage=new LoginPage();
}

@Test
public void login_test() throws InterruptedException
{
	loginpage.login();
}
}