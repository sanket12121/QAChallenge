package aspire.qa.test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import aspire.qa.base.TestBase;
import aspire.qa.pages.HomePage;
import aspire.qa.pages.InventoryPage;
import aspire.qa.pages.LoginPage;

public class InventoryPageTest extends TestBase{
	
	public LoginPage loginpage;
	public HomePage homepage;
	public InventoryPage inventorypage;
	public InventoryPageTest()
	{
		super();
	}
	
	@BeforeMethod
	public void setup() throws InterruptedException
	{
		initializaton();
		loginpage = new LoginPage();
		loginpage.login();
		homepage = new HomePage();
		homepage.navigatetoinventory();
		inventorypage = new InventoryPage();
	}
	
	@Test
	public void createproduct_test() throws InterruptedException
	{
		inventorypage.Createproduct();
	}

}
