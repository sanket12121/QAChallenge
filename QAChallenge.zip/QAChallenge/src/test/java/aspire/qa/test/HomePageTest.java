package aspire.qa.test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import aspire.qa.base.TestBase;
import aspire.qa.pages.HomePage;
import aspire.qa.pages.LoginPage;

public class HomePageTest extends TestBase{
	
	public LoginPage loginpage;
	public HomePage homepage;
	
	public HomePageTest()
	{
		super();
	}
	
	@BeforeMethod
	public void setup() throws InterruptedException
	{
		initializaton();
		loginpage = new LoginPage();
		loginpage.login();
		homepage = new HomePage();
	}
	
	
	@Test
	public void navigatetoinventory_test() throws InterruptedException
	{
		homepage.navigatetoinventory();
	}
}